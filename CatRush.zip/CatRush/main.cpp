#include "raylib.h"
#include "raymath.h"

int main()
{
    int WindowDimensions = 700;
    InitWindow(WindowDimensions, WindowDimensions, "StickerCat");

    // Player Variables
    Vector2 PlayerSize{50.f, 50.f}; // Default = 60.f
    Vector2 PlayerPos{(GetScreenHeight() - PlayerSize.y) / 2, (GetScreenWidth() - PlayerSize.x) / 2};

    Rectangle PlayerRec{PlayerPos.x, PlayerPos.y, PlayerSize.x, PlayerSize.y};

    Color PlayerColour = BLANK;

    int Speed = 2;

    int DashTime = 15;
    int DashCounter = 0;
    int Dash = 5;
    int DashBool = false;

    // Target Variables
    Vector2 TargetSize{30.f, 30.f};                                                    // Default = 30.f
    Vector2 TargetPos{(float)GetRandomValue(50, 650), (float)GetRandomValue(50, 650)}; // (float)GetRandomValue(50, 650) both

    Rectangle TargetRec{TargetPos.x, TargetPos.y, TargetSize.x, TargetSize.y};

    int DefaultAm = 50;
    int Amount = DefaultAm;
    int Goal = 0;
    int Lose = 0;
    int Number = 0;
    int MinRand = 30;
    int MaxRand = 670;

    bool GoalBool = false;
    bool LoseBool = false;

    float TarrX[Amount] = {};
    float TarrY[Amount] = {};

    Color TCarr[Amount] = {};
    Color SqColour = BLANK;

    // Timer Variable
    int Timer = 0;
    int DisplayT = Amount;
    int TimerX = 50;
    int TimerY = 180;
    Color DARKRED{139, 0, 0, 255};
    Color DARKORANGE{200, 100, 0, 255};
    Color TimeColour = DARKGREEN;

    // Texture Variables
    Texture2D Apple = LoadTexture("images/Food/AppleColourNew.png");
    Texture2D Cat = LoadTexture("images/BaseCatFace/CatColourNew.png");
    Texture2D RushCat = LoadTexture("images/RushedCatFace/CatRushedIdleNew.png");
    Texture2D DeadCat = LoadTexture("images/CatDead/CatDeadNew.png");
    // Texture2D Flower = LoadTexture("images/AaronStuff/FlowerNew.png");

    // Base Movement Texture Variables
    Texture2D CatUp = LoadTexture("images/BaseCatFace/CatColourUpNew.png");
    Texture2D CatLeft = LoadTexture("images/BaseCatFace/CatColourLeftNew.png");
    Texture2D CatDown = LoadTexture("images/BaseCatFace/CatColourDownNew.png");
    Texture2D CatRight = LoadTexture("images/BaseCatFace/CatColourRightNew.png");

    // Rush Movement Texture Variables
    Texture2D RCatUp = LoadTexture("images/RushedCatFace/CatRushedUpNew.png");
    Texture2D RCatLeft = LoadTexture("images/RushedCatFace/CatRushedLeftNew.png");
    Texture2D RCatDown = LoadTexture("images/RushedCatFace/CatRushedDownNew.png");
    Texture2D RCatRight = LoadTexture("images/RushedCatFace/CatRushedRightNew.png");

    // Font Variable
    Font Text = LoadFont("fonts/Letters.TTF");
    Color Tint = WHITE;

    // Main Project
    SetTargetFPS(60);
    while (WindowShouldClose() == false)
    {
        BeginDrawing();
        ClearBackground(LIME);
         
        if (DisplayT == 0)
        {
            TimeColour = DARKRED;
            ClearBackground(RED);
            DrawTextEx(Text, "You Lose!", {30, 50}, 90, 0, DARKRED);
            DrawTextEx(Text, "Press", {170, 500}, 90, 0, DARKRED);
            DrawTextEx(Text, "Enter", {170, 600}, 90, 0, DARKRED);
            TimerX = 210;
            if (IsKeyPressed(KEY_ENTER))
            {
                Amount = DefaultAm;
                DisplayT = DefaultAm;
                Goal = 0;
                Lose = 0;
                Timer = 0;
                TimerX = 50;
                TimerY = 180;
                LoseBool = true;
                TimeColour = DARKGREEN;
                ClearBackground(LIME);
            }
        }

        if (DisplayT != 0)
        {
            DrawTextEx(Text, "Collect", {110, 0}, 90, 0, TimeColour);
            DrawTextEx(Text, "Food!", {200, 80}, 90, 0, TimeColour);
        }
        DrawTextEx(Text, TextFormat("%d", DisplayT), {(float)TimerX, (float)TimerY}, 350, 0, TimeColour);
        
        // Time
        if (DisplayT <= 19)
        {
            TimerX = 100;
        }
        if (DisplayT <= 9 && DisplayT != 0)
        {
            TimerX = 210;
            ClearBackground(ORANGE);
            TimeColour = DARKORANGE;
        }

        // Randomise Target Position and Keep position in Array
        if (Number < Amount)
        {
            for (int i = 0; i < Amount; ++i)
            {
                TarrX[i] = GetRandomValue(MinRand, MaxRand);
                TarrY[i] = GetRandomValue(MinRand, MaxRand);
                TCarr[i] = SqColour;
                ++Number;
            }
        }

        // Draw Targets on Screen in accord to the "Amount" number
        for (int i = 0; i < Amount; ++i)
        {
            TargetRec.x = TarrX[i];
            TargetRec.y = TarrY[i];

            if (CheckCollisionRecs(PlayerRec, TargetRec))
            {
                TarrX[i] = -TargetSize.x - 1; // Default = -TargetSize.x - 1;
                TarrY[i] = -TargetSize.y - 1; // Default = -TargetSize.y - 1;
                ++Goal;
                if (Goal == Amount)
                {
                    GoalBool = true;
                }
            }

            if (GoalBool == true) // LoseBool == true
            {
                TarrX[i] = GetRandomValue(MinRand, MaxRand);
                TarrY[i] = GetRandomValue(MinRand, MaxRand);
                TCarr[i] = SqColour;
                --Goal;
                Timer = 0;
                TimerX = 50;
                TimeColour = DARKGREEN;

                if (Goal == 0)
                {
                    Goal = 0;
                    GoalBool = false;
                    --Amount;
                    DisplayT = Amount;
                }
            }

            if (LoseBool == true)
            {
                TarrX[i] = GetRandomValue(MinRand, MaxRand);
                TarrY[i] = GetRandomValue(MinRand, MaxRand);
                TCarr[i] = SqColour;
                ++Lose;
                Timer = 0;
                TimerX = 50;
                if (Lose == DefaultAm)
                {
                    LoseBool = false;
                }
            }
            DrawRectangleRec(TargetRec, TCarr[i]);
            DrawTexture(Apple, TargetRec.x, TargetRec.y, WHITE);
        }

        // Draw Text
        // DrawText(TextFormat("Goal: %d", Goal), 100, 100, 5, RED);
        // DrawText(TextFormat("Lose: %d", Lose), 100, 130, 5, PURPLE);
        // DrawText(TextFormat("Amount: %d", Amount), 200, 100, 5, GREEN);
        // DrawText(TextFormat("DashTime: %d", DashTime), 300, 100, 5, BROWN);
        // DrawText(TextFormat("DashCounter: %d", DashCounter), 400, 100, 5, LIME);
        // DrawText(TextFormat("Timer: %d", Timer), 500, 100, 5, SKYBLUE);
        // DrawText(TextFormat("MouseX: %d", GetMouseX()), 0, 50, 10, WHITE);
        // DrawText(TextFormat("MouseY: %d", GetMouseY()), 70, 50, 10, WHITE);

        // Draw Player
        DrawRectangleRec(PlayerRec, PlayerColour);

        // IncrementTime
        if (DisplayT != 0)
        {
            Timer += 1.0f;
        }

        // Change Display Timer by 1 each second
        if (Timer == 60 && DisplayT != 0)
        {
            DisplayT -= 1;
            Timer = 0;
        }

        // Dash Mechanic Activate
        if (IsKeyPressed(KEY_SPACE) && DashBool == false && (IsKeyDown(KEY_W) || IsKeyDown(KEY_A) || IsKeyDown(KEY_S) || IsKeyDown(KEY_D)) && DisplayT != 0) // DefaultKey = KEY_U
        {
            DashBool = true;
        }
        if (DashTime <= DashCounter)
        {
            DashBool = false;
            DashCounter = 0;
        }

        // Dash Mechanic Inputs
        if (DashBool == true && IsKeyDown(KEY_W) && PlayerRec.y > 0 && DisplayT != 0)
        {
            PlayerRec.y -= Dash * GetFrameTime() * 100;
            ++DashCounter;
        }
        if (DashBool == true && IsKeyDown(KEY_A) && PlayerRec.x > 0 && DisplayT != 0)
        {
            PlayerRec.x -= Dash * GetFrameTime() * 100;
            ++DashCounter;
        }
        if (DashBool == true && IsKeyDown(KEY_S) && PlayerRec.y < GetScreenHeight() - PlayerSize.y && DisplayT != 0)
        {
            PlayerRec.y += Dash * GetFrameTime() * 100;
            ++DashCounter;
        }
        if (DashBool == true && IsKeyDown(KEY_D) && PlayerRec.x < GetScreenWidth() - PlayerSize.x && DisplayT != 0)
        {
            PlayerRec.x += Dash * GetFrameTime() * 100;
            ++DashCounter;
        }

        // Controls player direction
        if (IsKeyDown(KEY_W) && PlayerRec.y > 0 && DisplayT != 0) // DisplayT != 0
        {
            PlayerRec.y -= GetFrameTime() * (100 * Speed);
            if (DisplayT <= 9)
            {
                DrawTexture(RCatUp, PlayerRec.x, PlayerRec.y, Tint);
            }
            else
            {
                DrawTexture(CatUp, PlayerRec.x, PlayerRec.y, Tint);
            }
        }
        if (IsKeyDown(KEY_A) && PlayerRec.x > 0 && DisplayT != 0)
        {
            PlayerRec.x -= GetFrameTime() * (100 * Speed);
            if (DisplayT <= 9)
            {
                DrawTexture(RCatLeft, PlayerRec.x, PlayerRec.y, Tint);
            }
            else
            {
                DrawTexture(CatLeft, PlayerRec.x, PlayerRec.y, Tint);
            }
        }
        if (IsKeyDown(KEY_S) && PlayerRec.y < GetScreenHeight() - PlayerSize.y && DisplayT != 0)
        {
            PlayerRec.y += GetFrameTime() * (100 * Speed);
            if (DisplayT <= 9)
            {
                DrawTexture(RCatDown, PlayerRec.x, PlayerRec.y, Tint);
            }
            else
            {
                DrawTexture(CatDown, PlayerRec.x, PlayerRec.y, Tint);
            }
        }
        if (IsKeyDown(KEY_D) && PlayerRec.x < GetScreenWidth() - PlayerSize.x && DisplayT != 0)
        {
            PlayerRec.x += GetFrameTime() * (100 * Speed);
            if (DisplayT <= 9)
            {
                DrawTexture(RCatRight, PlayerRec.x, PlayerRec.y, Tint);
            }
            else
            {
                DrawTexture(CatRight, PlayerRec.x, PlayerRec.y, Tint);
            }
        }
        
        // Check if the Cat is not moving and draws the texture to accomdate that
        if ((!IsKeyDown(KEY_W) && !IsKeyDown(KEY_A) && !IsKeyDown(KEY_S) && !IsKeyDown(KEY_D)) || DisplayT == 0)
        {
            if (DisplayT == 0)
            {
                DrawTexture(DeadCat, PlayerRec.x, PlayerRec.y, Tint);
            }

            if (DisplayT <= 9 && DisplayT != 0)
            {
                DrawTexture(RushCat, PlayerRec.x, PlayerRec.y, Tint);
            }
            else if (DisplayT > 9 || DisplayT != 0)
            {
                DrawTexture(Cat, PlayerRec.x, PlayerRec.y, Tint);
            }
        }

        // Drawing Textures for the edge of the map
        if ((PlayerRec.y < 0) || (PlayerRec.y > GetScreenHeight() - PlayerSize.y))
        {
            if (DisplayT <= 9)
            {
                DrawTexture(RushCat, PlayerRec.x, PlayerRec.y, Tint);
            }
            else
            {
                DrawTexture(Cat, PlayerRec.x, PlayerRec.y, Tint);
            }
            if (IsKeyDown(KEY_A))
            {
                if (DisplayT <= 9)
                {
                    DrawTexture(RCatLeft, PlayerRec.x, PlayerRec.y, Tint);
                }
                else
                {
                    DrawTexture(CatLeft, PlayerRec.x, PlayerRec.y, Tint);
                }
            }
            else if (IsKeyDown(KEY_D))
            {
                if (DisplayT <= 9)
                {
                    DrawTexture(RCatRight, PlayerRec.x, PlayerRec.y, Tint);
                }
                else
                {
                    DrawTexture(CatRight, PlayerRec.x, PlayerRec.y, Tint);
                }
            }
        }
        else if ((PlayerRec.x < 0) || (PlayerRec.x > GetScreenWidth() - PlayerSize.x))
        {
            if (DisplayT <= 9)
            {
                DrawTexture(RushCat, PlayerRec.x, PlayerRec.y, Tint);
            }
            else
            {
                DrawTexture(Cat, PlayerRec.x, PlayerRec.y, Tint);
            }
            if (IsKeyDown(KEY_W))
            {
                if (DisplayT <= 9)
                {
                    DrawTexture(RCatUp, PlayerRec.x, PlayerRec.y, Tint);
                }
                else
                {
                    DrawTexture(CatUp, PlayerRec.x, PlayerRec.y, Tint);
                }
            }
            else if (IsKeyDown(KEY_S))
            {
                if (DisplayT <= 9)
                {
                    DrawTexture(RCatDown, PlayerRec.x, PlayerRec.y, Tint);
                }
                else
                {
                    DrawTexture(CatDown, PlayerRec.x, PlayerRec.y, Tint);
                }
            }
        }

        EndDrawing();
    }
    // Unload Textures
    UnloadTexture(Cat);
    UnloadTexture(CatUp);
    UnloadTexture(CatDown);
    UnloadTexture(CatRight);
    UnloadTexture(CatLeft);
    UnloadTexture(Apple);

    // Unload Fonts
    UnloadFont(Text);
}